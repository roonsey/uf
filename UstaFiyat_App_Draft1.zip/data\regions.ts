export interface Region {
    id: string;
    name: string;
    slug: string; // SEO URL
    tier: 1 | 2 | 3;
    multiplier: number;
}

export const REGIONS: Region[] = [
    // Tier 1: Mega
    { id: "istanbul", name: "İstanbul", slug: "istanbul", tier: 1, multiplier: 1.35 },

    // Tier 2: Major
    { id: "ankara", name: "Ankara", slug: "ankara", tier: 2, multiplier: 1.20 },
    { id: "izmir", name: "İzmir", slug: "izmir", tier: 2, multiplier: 1.25 }, // İzmir often slightly pricier than Ankara for services
    { id: "bursa", name: "Bursa", slug: "bursa", tier: 2, multiplier: 1.15 },
    { id: "antalya", name: "Antalya", slug: "antalya", tier: 2, multiplier: 1.20 },
    { id: "kocaeli", name: "Kocaeli", slug: "kocaeli", tier: 2, multiplier: 1.15 },
    { id: "mugla", name: "Muğla", slug: "mugla", tier: 2, multiplier: 1.20 }, // Bodrum etc interaction

    // Tier 3: Cities
    { id: "adana", name: "Adana", slug: "adana", tier: 3, multiplier: 1.10 },
    { id: "gaziantep", name: "Gaziantep", slug: "gaziantep", tier: 3, multiplier: 1.10 },
    { id: "konya", name: "Konya", slug: "konya", tier: 3, multiplier: 1.05 },
    { id: "eskisehir", name: "Eskişehir", slug: "eskisehir", tier: 3, multiplier: 1.10 },
    { id: "mersin", name: "Mersin", slug: "mersin", tier: 3, multiplier: 1.05 },
    { id: "kayseri", name: "Kayseri", slug: "kayseri", tier: 3, multiplier: 1.05 },
    { id: "samsun", name: "Samsun", slug: "samsun", tier: 3, multiplier: 1.05 },
    { id: "denizli", name: "Denizli", slug: "denizli", tier: 3, multiplier: 1.05 },
    { id: "tekirdag", name: "Tekirdağ", slug: "tekirdag", tier: 3, multiplier: 1.10 },

    { id: "other", name: "Diğer Şehirler", slug: "diger", tier: 3, multiplier: 1.0 }
];

export const REGION_MULTIPLIERS: Record<string, number> = REGIONS.reduce((acc, region) => {
    acc[region.name] = region.multiplier;
    return acc;
}, {} as Record<string, number>);
