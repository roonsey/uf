export interface BlogPost {
    id: string;
    slug: string;
    title: string;
    excerpt: string;
    content: string; // Markdown-like or HTML
    date: string;
    readTime: string;
    image: string; // Emoji or placeholder for now
}

export const BLOG_POSTS: BlogPost[] = [
    {
        id: "1",
        slug: "2025-usta-fiyatlari-rehberi",
        title: "2025 Yılı Güncel Usta ve Tadilat Fiyatları",
        excerpt: "Yeni yılda boya, tesisat ve elektrik işçilik ücretleri ne kadar oldu? İşte İstanbul, Ankara ve İzmir için detaylı fiyat analizi.",
        date: "1 Ocak 2025",
        readTime: "5 dk okuma",
        image: "💰",
        content: `
## 2025 Yılında Tadilat Fiyatları Neden Arttı?
Enflasyon ve asgari ücret artışları, malzeme maliyetlerinin yanı sıra işçilik ücretlerini de doğrudan etkiledi. Özellikle **Boya Badana** ve **Seramik** işçiliklerinde %40'a varan artışlar gözlemleniyor.

### Tesisatçı Ücretleri 2025
Bir su tesisatçısının servis ücreti ortalama **400 TL**'den başlıyor. Basit bir musluk değişimi bile malzeme dahil **800-1100 TL** bandına oturmuş durumda. Robotla tıkanıklık açma işlemleri ise **1500 TL** seviyelerinde.

### Elektrikçi Fiyatları
Avize montajı artık "basit iş" olarak görülmüyor. Matkap kullanımı, tavan delme riski ve harcanan zaman nedeniyle tekli avize montajı **350-500 TL** arasında değişiyor.

### Boya Badana
2+1 boş bir dairenin boyanması (malzeme dahil) 2025 yılında ortalama **12.000 TL**'den başlıyor. Eşyalı dairelerde bu rakam %20-30 daha yüksek.

**Öneri:** Fiyat alırken mutlaka "Malzeme Dahil mi?" diye sorun ve kullanılacak boyanın markasını (Marshall, Filli Boya, Jotun vb.) teyit edin.
        `
    },
    {
        id: "2",
        slug: "musluk-batarya-degisimi-puf-noktalari",
        title: "Musluk Değiştirirken Kazıklanmayın: Nelere Dikkat Etmeli?",
        excerpt: "Usta çağırmadan önce bilmeniz gerekenler. Hangi batarya kaliteli? İşçilik ücreti ne kadar olmalı?",
        date: "28 Aralık 2024",
        readTime: "3 dk okuma",
        image: "🚰",
        content: `
## Kaliteli Batarya Nasıl Anlaşılır?
Piyasada 200 TL'ye de 5000 TL'ye de batarya var. Ucuz bataryalar genellikle "zamak" denilen dayanıksız alaşımdan yapılır ve 1-2 yıl içinde patlar/çatlar.
Gerçek **pirinç (sarı)** malzemeden yapılmış bataryalar ağırdır ve yıllarca dayanır.

### Usta Gelmeden Önce...
1. **Fotoğraf Çekin:** Mevcut musluğun fotoğrafını ustaya atın.
2. **Ara Muslukları Kontrol Edin:** Eğer ara musluklar (taharet muslukları) çürümüşse, usta gelmişken onları da değiştirmesini isteyin.
3. **Fiyatı Baştan Konuşun:** "Bakarız, hallederiz" diyen ustadan uzak durun. UstaFiyat hesaplayıcısını kullanarak ortalama fiyatı öğrenin.
        `
    },
    {
        id: "3",
        slug: "kombi-bakimi-ne-zaman-yapilmali",
        title: "Kış Gelmeden Kombi Bakımı ve Petek Temizliği",
        excerpt: "Faturanızın %30 düşmesi için petek temizliği şart mı? Kombi bakımı dolandırıcılığına dikkat!",
        date: "15 Kasım 2024",
        readTime: "4 dk okuma",
        image: "🔥",
        content: `
## Petek Temizliği Yalan mı Gerçek mi?
Peteklerin altı soğuk, üstü sıcaksa temizlik vakti gelmiştir. Çamurlaşmış su devirdaimi engeller ve kombiyi zorlar. **Makineli ilaçlı temizlik** yaptıranlarda %20-%30 yakıt tasarrufu görülmektedir.

### Sahte Servislere Dikkat
İnternette "Yetkili Servis" diye arattığınızda çıkan ilk numaraların çoğu aslında özel (korsan) servislerdir. 
*   Parça değiştirmeden "değiştirdik" diyebilirler.
*   Piyasa değerinin 5 katı fiyat çekebilirler.

Mutlaka markanın **resmi web sitesinden** yetkili servis numarasını bulun.
        `
    }
]
