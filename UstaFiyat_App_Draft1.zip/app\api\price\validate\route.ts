import { NextResponse } from "next/server"
import { validatePriceWithDetails } from "../../../../lib/pricing-engine"

// Helper to generate explanation without AI
function generateExplanation(result: any, city: string, taskName: string, duration: number) {
    const { status, calculation, userPrice } = result
    const { min, max } = calculation.range

    let text = ""

    if (status === "below") {
        const diff = Math.round(((min - userPrice) / min) * 100)
        text = `Bu fiyat, ${city} için ${taskName} işlemi adına hesaplanan beklenen alt sınırın (${min} TL) yaklaşık %${diff} altındadır.`
    } else if (status === "normal") {
        text = `Bu fiyat (${userPrice} TL), ${city} için ${taskName} işlemi adına hesaplanan piyasa koşullarına uygundur (Referans aralık: ${min} TL - ${max} TL).`
    } else {
        // High or Extreme
        const diff = Math.round(((userPrice - max) / max) * 100)
        const label = status === "extreme" ? "aşırı" : ""
        text = `Bu fiyat, ${city} için ${taskName} işlemi adına hesaplanan üst sınırın yaklaşık %${diff} üzerindedir.`
        if (status === "extreme") {
            text += " (Piyasa koşullarına göre olağan dışı yüksektir)."
        }
    }

    // Mandatory additions per system rules
    text += ` Bu işlem genellikle ${duration} dakika sürmektedir.`
    text += `\n\nFiyatlar yerinde tespit ve değişken koşullara göre farklılık gösterebilir.`

    return text
}

export async function POST(req: Request) {
    try {
        const body = await req.json()

        // 1. Strict Input Validation
        if (!body.taskId || !body.city) {
            return NextResponse.json(
                { error: "İş türü (taskId) ve şehir seçimi zorunludur." },
                { status: 400 }
            )
        }

        // 2. Deterministic Calculation
        const engineResult = validatePriceWithDetails({
            taskId: body.taskId,
            city: body.city,
            urgencyLevel: body.urgencyLevel || "normal",
            materialIncluded: body.materialIncluded ?? false,
            materialQuality: body.materialQuality || "standard",
            userProvidedPrice: Number(body.userProvidedPrice)
        })

        // 3. Local Explanation Generation (No AI)
        const explanation = generateExplanation(
            engineResult,
            body.city,
            engineResult.calculation.taskMeta.name,
            engineResult.calculation.taskMeta.duration
        )

        // 4. Return Combined Result
        return NextResponse.json({
            data: engineResult,
            explanation: explanation
        })

    } catch (error: any) {
        console.error("API Error:", error)
        return NextResponse.json(
            { error: error.message || "Internal Server Error" },
            { status: 500 }
        )
    }
}
