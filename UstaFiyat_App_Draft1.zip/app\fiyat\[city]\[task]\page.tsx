import { TASKS } from "../../../../data/tasks"
import { REGIONS } from "../../../../data/regions"
import { calculatePrice } from "../../../../lib/pricing-engine"
import Link from "next/link"

// SEO: Generate Valid Routes
export async function generateStaticParams() {
    // Generate simple combinations to avoid build timeout if tons,
    // but here we have ~20 tasks * ~15 regions = 300 pages. Fast enough.

    // NOTE: In a real expanded app, you might lazily render these or cap them.
    // For now we do mostly popular combinations or all.
    const params = []

    for (const city of REGIONS) {
        if (city.id === 'other') continue
        for (const taskKey in TASKS) {
            const task = TASKS[taskKey]
            params.push({
                city: city.slug,
                task: task.slug
            })
        }
    }
    return params
}

export async function generateMetadata({ params }: { params: { city: string, task: string } }) {
    const { city, task } = await params

    const regionName = REGIONS.find(r => r.slug === city)?.name || city
    const taskData = Object.values(TASKS).find(t => t.slug === task)
    const taskName = taskData?.name || task

    return {
        title: `${regionName} ${taskName} Fiyatları 2025 | UstaFiyat`,
        description: `${regionName} bölgesinde ${taskName} işlemi için güncel adil fiyat aralıklarını öğrenin. Ustanın verdiği fiyat normal mi? Hemen sorgulayın.`
    }
}

export default async function TaskPricePage({ params }: { params: { city: string, task: string } }) {

    const { city, task } = await params

    // Lookup Data
    const region = REGIONS.find(r => r.slug === city)
    const taskData = Object.values(TASKS).find(t => t.slug === task)

    if (!region || !taskData) {
        return <div className="p-10 text-center">Sayfa bulunamadı.</div>
    }

    // Pre-calculate Standard Range for Display
    const priceInfo = calculatePrice({
        taskId: taskData.id,
        city: region.name,
        urgencyLevel: 'normal',
        materialIncluded: true // Assume material included for the "landing page SEO view" usually
    })

    const { min, max } = priceInfo.range

    return (
        <div className="min-h-screen bg-white">
            {/* Nav */}
            <nav className="p-4 border-b flex justify-between items-center bg-zinc-50">
                <Link href="/" className="font-bold text-xl tracking-tighter">UstaFiyat</Link>
                <Link href="/" className="text-sm underline">Başa Dön</Link>
            </nav>

            <main className="max-w-3xl mx-auto py-12 px-6">

                {/* Hero Data */}
                <h1 className="text-3xl md:text-5xl font-bold mb-6 text-zinc-900 leading-tight">
                    {region.name} <br />
                    <span className="text-blue-600">{taskData.name}</span> Fiyatı
                </h1>

                <div className="p-6 bg-zinc-50 rounded-2xl border border-zinc-200 mb-8">
                    <div className="grid grid-cols-2 gap-8 text-center">
                        <div>
                            <div className="text-zinc-500 text-sm mb-1">Tahmini Süre</div>
                            <div className="font-bold text-xl">{taskData.durationMinutes} Dakika</div>
                        </div>
                        <div>
                            <div className="text-zinc-500 text-sm mb-1">Zorluk Seviyesi</div>
                            <div className="font-bold text-xl">{taskData.difficulty}/5</div>
                        </div>
                    </div>
                </div>

                {/* Big Price Range */}
                <div className="text-center mb-12">
                    <p className="text-zinc-500 mb-2">2025 Güncel Piyasa Ortalaması</p>
                    <div className="text-5xl md:text-7xl font-bold tracking-tighter text-zinc-900">
                        {min} - {max} <span className="text-2xl text-zinc-400 font-normal">TL</span>
                    </div>
                    <p className="text-sm text-zinc-400 mt-4 max-w-md mx-auto">
                        *Bu fiyat aralığı malzeme dahil, standart koşullar için tahmini değerdir.
                        Ustanın verdiği fiyatı kesin olarak doğrulamak için aşağıdaki aracı kullanın.
                    </p>
                </div>

                <div className="bg-blue-600 text-white p-8 rounded-3xl text-center shadow-xl shadow-blue-200">
                    <h3 className="text-2xl font-bold mb-4">Ustanız farklı bir fiyat mı verdi?</h3>
                    <p className="mb-6 opacity-90">
                        Aciliyet durumu, malzeme kalitesi veya şehir farkı fiyatı değiştirebilir.
                        Size verilen fiyatın adil olup olmadığını hemen ücretsiz sorgulayın.
                    </p>
                    <Link
                        href="/"
                        className="inline-block bg-white text-blue-800 font-bold py-3 px-8 rounded-xl hover:scale-105 transition-transform"
                    >
                        Hemen Fiyatı Doğrula →
                    </Link>
                </div>

            </main>

            {/* Footer SEO Text */}
            <footer className="max-w-3xl mx-auto px-6 py-12 text-zinc-500 text-sm leading-relaxed border-t mt-12">
                <p className="mb-4">
                    <strong>{region.name} {taskData.name} Ücretleri:</strong> {new Date().getFullYear()} yılı itibariyle {region.name} genelinde
                    {taskData.name} hizmeti için fiyatlar işçilik, malzeme kalitesi ve konumun ulaşılabilirliğine göre değişmektedir.
                    En doğru fiyat karşılaştırması için UstaFiyat algoritmasını kullanarak spesifik teklifinizi değerlendirin.
                </p>
                <p>
                    Hizmet Kategorisi: {taskData.categoryId.toUpperCase()}
                </p>
            </footer>
        </div>
    )
}
