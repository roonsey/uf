import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const viewport = {
  themeColor: '#000000',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false, // Prevents zooming -> Native feel
}

export const metadata: Metadata = {
  title: 'UstaFiyat | Hizmet Fiyatı Doğrulama ve Hesaplama',
  description: 'Evinizdeki ustalık işleri için verilen fiyatları anında doğrulayın. Musluk değişimi, boya badana, elektrik ve temizlik işleri için 2025 güncel piyasa fiyatlarını öğrenin.',
  manifest: '/manifest.json',
  icons: {
    icon: '/icon.svg',
    apple: '/icon.svg',
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: 'black-translucent',
    title: 'UstaFiyat',
  },
  keywords: ['usta fiyatları', 'tadilat hesaplama', 'boya badana fiyatı', 'tesisatçı ücretleri', 'elektrikçi fiyatları 2025'],
  openGraph: {
    // ... existing openGraph

    title: 'UstaFiyat - Adil Fiyat mı?',
    description: 'Ustanızın verdiği fiyatı yapay zeka destekli algoritmamızla saniyeler içinde analiz edin.',
    url: 'https://ustafiyat.com',
    siteName: 'UstaFiyat',
    locale: 'tr_TR',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'UstaFiyat | Fiyat Doğrulama',
    description: 'Adil hizmet fiyatlarını anında öğrenin.'
  },
  robots: {
    index: true,
    follow: true,
  }
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="tr">
      <body className={inter.className}>{children}</body>
    </html>
  )
}
