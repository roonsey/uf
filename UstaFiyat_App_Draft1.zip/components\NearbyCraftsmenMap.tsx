"use client"

import { TASKS } from "../data/tasks"

interface NearbyCraftsmenMapProps {
    city: string
    district: string
    taskId: string
}

export function NearbyCraftsmenMap({ city, district, taskId }: NearbyCraftsmenMapProps) {
    const task = TASKS[taskId]
    const taskName = task ? task.name.split('(')[0] : "Usta" // Clean name "Klima Montajı (Split)" -> "Klima Montajı"

    // Construct search query: "Kadıköy Sıhhi Tesisatçı" or "Beşiktaş Klima Servisi"
    // Heuristic mapping for better Google Maps results
    let serviceTerm = taskName
    if (task?.categoryId === 'plumbing') serviceTerm = "Su Tesisatçısı"
    if (task?.categoryId === 'electric') serviceTerm = "Elektrikçi"
    if (task?.categoryId === 'painting') serviceTerm = "Boyacı Ustası"
    if (task?.categoryId === 'ac') serviceTerm = "Klima Servisi"
    if (task?.categoryId === 'heating') serviceTerm = "Kombi Servisi"
    if (task?.categoryId === 'locksmith') serviceTerm = "Çilingir"
    if (task?.categoryId === 'cleaning') serviceTerm = "Temizlik Şirketi"

    const query = `${district} ${city} ${serviceTerm}`
    const embedUrl = `https://www.google.com/maps/embed/v1/search?key=${process.env.NEXT_PUBLIC_GOOGLE_MAPS_KEY || 'YOUR_API_KEY_HERE_IF_HAVE_ONE_BUT_USING_IFRAME_SEARCH_MODE_IS_FREE'}&q=${encodeURIComponent(query)}`

    // Actually, "embed/v1/search" requires an API Key. 
    // The completely free, no-key way is using the older iframe output from maps website or the "maps?q=" logic which might refuse to embed.
    // The most robust free way is using the direct maps embed iframe that businesses use, but dynamically.
    // Let's use the standard "https://maps.google.com/maps?q=...&t=&z=13&ie=UTF8&iwloc=&output=embed" format which is widely used as a free hack/workaround.

    const freeEmbedUrl = `https://maps.google.com/maps?q=${encodeURIComponent(query)}&t=&z=14&ie=UTF8&iwloc=&output=embed`

    return (
        <div className="w-full bg-white rounded-2xl border border-zinc-200 overflow-hidden shadow-sm mt-8">
            <div className="p-4 border-b border-zinc-100 bg-zinc-50 flex justify-between items-center">
                <div>
                    <h3 className="font-bold text-zinc-900">Yakındaki Ustalar</h3>
                    <p className="text-xs text-zinc-500">Google Haritalar üzerinden bölgenizdeki en yakın hizmet sağlayıcılar.</p>
                </div>
                <div className="flex items-center gap-1 text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded-lg">
                    <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                    Canlı
                </div>
            </div>

            <div className="relative w-full h-[350px] bg-zinc-100">
                <iframe
                    width="100%"
                    height="100%"
                    src={freeEmbedUrl}
                    frameBorder="0"
                    scrolling="no"
                    marginHeight={0}
                    marginWidth={0}
                    title="Yakındaki Ustalar"
                    className="opacity-0 animate-in fade-in duration-1000 fill-mode-forwards"
                    onLoad={(e) => (e.target as HTMLIFrameElement).classList.remove('opacity-0')}
                >
                </iframe>

                {/* Overlay to prevent accidental scrolls if needed, but for maps usually we want interaction */}
            </div>

            <div className="p-3 bg-blue-50 text-blue-800 text-xs text-center font-medium">
                ⚠️ Usta ile görüşürken "UstaFiyat Analiz Raporu"nuzu göstermeyi unutmayın!
            </div>
        </div>
    )
}
