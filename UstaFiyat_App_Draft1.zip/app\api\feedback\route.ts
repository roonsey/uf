import { NextResponse } from "next/server"

export async function POST(req: Request) {
    try {
        const body = await req.json()

        // In a real app, this would save to Supabase/Postgres/MongoDB
        // For MVP, we'll just log it to console to simulate data collection
        console.log("Crowd Data Received:", {
            timestamp: new Date().toISOString(),
            ...body
        })

        return NextResponse.json({ success: true })
    } catch (error) {
        return NextResponse.json({ success: false }, { status: 500 })
    }
}
