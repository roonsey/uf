"use client"

import { useState } from "react"
import { motion } from "framer-motion"

interface FeedbackFormProps {
    taskId: string;
    city: string;
    initialPrice: number;
}

export function FeedbackForm({ taskId, city, initialPrice }: FeedbackFormProps) {
    const [submitted, setSubmitted] = useState(false)
    const [agreed, setAgreed] = useState<"yes" | "no" | null>(null)
    const [finalPrice, setFinalPrice] = useState(initialPrice.toString())
    const [loading, setLoading] = useState(false)

    const handleSubmit = async () => {
        setLoading(true)
        try {
            await fetch("/api/feedback", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    taskId,
                    city,
                    agreed: agreed === "yes",
                    finalPrice: agreed === "yes" ? Number(finalPrice) : null,
                    initialOfferedPrice: initialPrice
                })
            })
            setSubmitted(true)
        } catch (e) {
            console.error(e)
        } finally {
            setLoading(false)
        }
    }

    if (submitted) {
        return (
            <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-8 p-6 bg-zinc-900 rounded-2xl text-center text-white"
            >
                <div className="text-2xl mb-2">🤝</div>
                <h3 className="font-bold mb-1">Teşekkürler!</h3>
                <p className="text-zinc-400 text-sm">
                    Geri bildiriminiz UstaFiyat algoritmasını geliştirmemize yardımcı olacak.
                </p>
            </motion.div>
        )
    }

    return (
        <div className="mt-8 border-t border-zinc-200 pt-8">
            <h4 className="font-bold text-center mb-4 text-zinc-800">Usta ile anlaştınız mı?</h4>

            {!agreed ? (
                <div className="flex gap-3 justify-center">
                    <button
                        onClick={() => setAgreed("yes")}
                        className="flex-1 max-w-[120px] py-3 rounded-xl border border-green-200 bg-green-50 text-green-700 font-bold hover:bg-green-100 transition-colors"
                    >
                        Evet
                    </button>
                    <button
                        onClick={() => setAgreed("no")}
                        className="flex-1 max-w-[120px] py-3 rounded-xl border border-zinc-200 bg-zinc-50 text-zinc-600 font-bold hover:bg-zinc-100 transition-colors"
                    >
                        Hayır
                    </button>
                </div>
            ) : (
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="bg-zinc-50 p-6 rounded-2xl border border-zinc-200"
                >
                    {agreed === "yes" ? (
                        <>
                            <label className="block text-sm font-medium text-zinc-700 mb-3 text-center">
                                Hangi fiyata el sıkıştınız?
                            </label>
                            <div className="flex gap-2 mb-4">
                                <input
                                    type="number"
                                    value={finalPrice}
                                    onChange={(e) => setFinalPrice(e.target.value)}
                                    className="flex-1 p-3 border border-zinc-300 rounded-xl text-center font-bold text-lg outline-none focus:border-black"
                                />
                                <span className="flex items-center font-bold text-zinc-500">TL</span>
                            </div>
                        </>
                    ) : (
                        <p className="text-center text-zinc-600 mb-4 text-sm">
                            Anlaşamamanıza üzüldük. Fiyat konusunda mı anlaşamadınız?
                        </p>
                    )}

                    <div className="flex gap-2">
                        <button
                            onClick={() => setAgreed(null)}
                            className="flex-1 py-3 text-zinc-500 hover:text-black transition-colors"
                        >
                            Geri
                        </button>
                        <button
                            onClick={handleSubmit}
                            disabled={loading}
                            className="flex-[2] bg-black text-white py-3 rounded-xl font-bold hover:bg-zinc-800 transition-colors"
                        >
                            {loading ? "Gönderiliyor..." : "Gönder"}
                        </button>
                    </div>
                </motion.div>
            )}
        </div>
    )
}
