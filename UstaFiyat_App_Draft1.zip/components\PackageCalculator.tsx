"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import packagesData from "../data/packages.json"
import { TASKS, Task } from "../data/tasks"
import { REGIONS } from "../data/regions"
import { calculatePrice } from "../lib/pricing-engine"

interface Package {
    id: string
    name: string
    description: string
    tasks: string[]
    discountMultiplier: number
    slug: string
}

export function PackageCalculator() {
    const [selectedPackage, setSelectedPackage] = useState<Package | null>(null)
    const [city, setCity] = useState("İstanbul") // Default
    const packages = packagesData as Package[]

    const calculatePackagePrice = (pkg: Package) => {
        let totalMin = 0
        let totalMax = 0
        let totalBaseLabor = 0
        let totalMaterial = 0

        // Find tasks
        const pkgTasks = pkg.tasks.map(id => TASKS[id]).filter(Boolean) as Task[]

        pkgTasks.forEach(task => {
            // Calculate individual price for each task assuming normal urgency, standard material
            // We reuse the engine logic but simplified here for instant display
            const result = calculatePrice({
                taskId: task.id,
                city: city,
                urgencyLevel: 'normal',
                materialIncluded: true,
                materialQuality: 'standard'
            })

            totalMin += result.range.min
            totalMax += result.range.max
            totalBaseLabor += task.baseLabor
            totalMaterial += task.materialCost
        })

        // Apply Bundle Discount
        const discountedMin = Math.round(totalMin * pkg.discountMultiplier)
        const discountedMax = Math.round(totalMax * pkg.discountMultiplier)

        return {
            min: discountedMin,
            max: discountedMax,
            originalMin: totalMin,
            savings: totalMin - discountedMin
        }
    }

    return (
        <section className="py-16 px-4 max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-4 tracking-tight">Akıllı Paketler</h2>
            <p className="text-zinc-500 text-center mb-10">Birden fazla işi aynı anda yaptırın, %15'e varan avantaj sağlayın.</p>

            <div className="flex justify-center mb-8">
                <select
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="p-3 bg-white border rounded-xl shadow-sm text-lg outline-none focus:border-black"
                >
                    {REGIONS.map(r => (
                        <option key={r.id} value={r.name}>{r.name}</option>
                    ))}
                </select>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
                {packages.map(pkg => {
                    const price = calculatePackagePrice(pkg)
                    return (
                        <motion.div
                            key={pkg.id}
                            whileHover={{ y: -5 }}
                            className="bg-white rounded-3xl p-6 border border-zinc-200 shadow-xl overflow-hidden relative group"
                        >
                            <div className="absolute top-0 right-0 bg-green-500 text-white text-xs font-bold px-3 py-1 rounded-bl-xl">
                                %{(100 - pkg.discountMultiplier * 100).toFixed(0)} İNDİRİM
                            </div>

                            <h3 className="font-bold text-xl mb-2">{pkg.name}</h3>
                            <p className="text-sm text-zinc-500 mb-4 h-10">{pkg.description}</p>

                            <div className="space-y-2 mb-6">
                                {pkg.tasks.map(taskId => {
                                    const t = TASKS[taskId]
                                    return (
                                        <div key={taskId} className="flex items-center text-sm text-zinc-600">
                                            <span className="w-4 h-4 mr-2 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-[10px]">✓</span>
                                            {t ? t.name : taskId}
                                        </div>
                                    )
                                })}
                            </div>

                            <div className="mt-auto border-t pt-4">
                                <div className="text-xs text-zinc-400 line-through mb-1">Ortalama: {price.originalMin.toLocaleString('tr-TR')} TL</div>
                                <div className="text-3xl font-bold text-black">{price.min.toLocaleString('tr-TR')} <span className="text-sm font-normal text-zinc-500">TL'den</span></div>
                                <div className="text-xs text-green-600 font-medium mt-1">
                                    Yaklaşık {price.savings.toLocaleString('tr-TR')} TL Kazanç
                                </div>
                            </div>
                        </motion.div>
                    )
                })}
            </div>
        </section>
    )
}
