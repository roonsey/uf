export interface Category {
    id: string;
    name: string;
    icon: string;
    description: string;
    slug: string;
}

export const CATEGORIES: Category[] = [
    {
        id: "plumbing",
        name: "Su Tesisatı",
        icon: "💧",
        description: "Musluk, gider, kaçak tespiti",
        slug: "su-tesisati"
    },
    {
        id: "electric",
        name: "Elektrik",
        icon: "⚡",
        description: "Priz, avize, sigorta",
        slug: "elektrik"
    },
    {
        id: "heating",
        name: "Isıtma & Kombi",
        icon: "🔥",
        description: "Kombi bakımı, petek temizliği",
        slug: "isitma-kombi"
    },
    {
        id: "painting",
        name: "Boya & Badana",
        icon: "🎨",
        description: "Oda boyama, ev boyama",
        slug: "boya-badana"
    },
    {
        id: "ac",
        name: "Klima",
        icon: "❄️",
        description: "Klima montaj, bakım, gaz dolumu",
        slug: "klima"
    },
    {
        id: "cleaning",
        name: "Temizlik",
        icon: "✨",
        description: "Ev temizliği, koltuk yıkama",
        slug: "temizlik"
    },
    {
        id: "locksmith",
        name: "Çilingir",
        icon: "🔑",
        description: "Kapı açma, kilit değiştirme",
        slug: "cilingir"
    },
    {
        id: "general",
        name: "Tadilat & Montaj",
        icon: "🔨",
        description: "Mobilya montajı, korniş",
        slug: "tadilat-montaj"
    }
];
