import { motion } from "framer-motion";

export const FAQ = () => {
    const faqs = [
        {
            q: "Fiyatlar neye göre hesaplanıyor?",
            a: "Verilerimiz, Türkiye genelindeki binlerce gerçek işlem verisi, malzeme fiyat endeksleri ve bölgesel işçilik katsayıları harmanlanarak oluşturulur.",
        },
        {
            q: "Bu fiyatlar kesin midir?",
            a: "Hayır, bu fiyatlar 'Adil Piyasa Ortalaması'dır. Ustanın tecrübesi, işin zorluğu ve anlık malzeme fiyat değişimleri son teklifi etkileyebilir.",
        },
        {
            q: "Neden şehre göre fiyat değişiyor?",
            a: "Büyükşehirlerdeki yaşam maliyeti, ulaşım zorluğu ve operasyonel giderler, işçilik fiyatlarına doğrudan yansımaktadır. Örneğin İstanbul katsayısı Anadolu'ya göre %30-35 daha yüksektir.",
        },
        {
            q: "Usta çok daha yüksek fiyat verdi, ne yapmalıyım?",
            a: "Analiz kartını ustaya göstererek pazarlık yapabilirsiniz. Ancak ustanın kullandığı malzeme kalitesi veya işin ekstra zorlukları varsa fiyat artışı normal olabilir.",
        },
    ];

    return (
        <section className="py-16 px-4 max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-10 tracking-tight">
                Sıkça Sorulan Sorular
            </h2>
            <div className="space-y-6">
                {faqs.map((item, i) => (
                    <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: i * 0.1 }}
                        key={i}
                        className="bg-white p-6 rounded-2xl border border-zinc-100 shadow-sm"
                    >
                        <h3 className="text-lg font-bold mb-2">{item.q}</h3>
                        <p className="text-zinc-600 leading-relaxed text-sm">{item.a}</p>
                    </motion.div>
                ))}
            </div>
        </section>
    );
};
