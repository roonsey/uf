export interface District {
    id: string;
    name: string;
    multiplier: number; // For micro-location pricing accuracy
}

export const DISTRICTS: Record<string, District[]> = {
    "İstanbul": [
        { id: "besiktas", name: "Beşiktaş", multiplier: 1.4 },
        { id: "kadikoy", name: "Kadıköy", multiplier: 1.35 },
        { id: "sisli", name: "Şişli", multiplier: 1.3 },
        { id: "bakirkoy", name: "Bakırköy", multiplier: 1.25 },
        { id: "uskudar", name: "Üsküdar", multiplier: 1.2 },
        { id: "atasehir", name: "Ataşehir", multiplier: 1.2 },
        { id: "fatih", name: "Fatih", multiplier: 1.1 },
        { id: "umraniye", name: "Ümraniye", multiplier: 1.0 },
        { id: "pendik", name: "Pendik", multiplier: 0.95 },
        { id: "esenyurt", name: "Esenyurt", multiplier: 0.9 },
        { id: "beylikduzu", name: "Beylikdüzü", multiplier: 0.9 },
        { id: "diger-ist", name: "Diğer (İstanbul)", multiplier: 1.0 }
    ],
    "Ankara": [
        { id: "cankaya", name: "Çankaya", multiplier: 1.2 },
        { id: "yenimahalle", name: "Yenimahalle", multiplier: 1.1 },
        { id: "kecioren", name: "Keçiören", multiplier: 1.0 },
        { id: "mamak", name: "Mamak", multiplier: 0.95 },
        { id: "etesgut", name: "Etimesgut", multiplier: 1.0 },
        { id: "diger-ank", name: "Diğer (Ankara)", multiplier: 1.0 }
    ],
    "İzmir": [
        { id: "karsiyaka", name: "Karşıyaka", multiplier: 1.25 },
        { id: "konak", name: "Konak", multiplier: 1.15 },
        { id: "bornova", name: "Bornova", multiplier: 1.1 },
        { id: "buca", name: "Buca", multiplier: 1.0 },
        { id: "diger-izm", name: "Diğer (İzmir)", multiplier: 1.0 }
    ]
    // Default fallback for other cities will be handled in UI
};
