import Link from "next/link"
import { BLOG_POSTS } from "../data/blog-posts"

export function BlogSection() {
    return (
        <section className="py-16 px-4 max-w-5xl mx-auto border-t border-zinc-100">
            <div className="flex items-center justify-between mb-8">
                <h2 className="text-3xl font-bold tracking-tight">Rehber ve İpuçları</h2>
                <Link href="/blog" className="text-sm font-medium text-zinc-500 hover:text-black transition-colors">
                    Tümünü Gör →
                </Link>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
                {BLOG_POSTS.map(post => (
                    <Link href={`/blog/${post.slug}`} key={post.id} className="group">
                        <div className="bg-zinc-50 rounded-2xl h-48 flex items-center justify-center text-6xl mb-4 group-hover:bg-zinc-100 transition-colors border border-zinc-100">
                            {post.image}
                        </div>
                        <div className="flex items-center gap-2 text-xs text-zinc-400 mb-2">
                            <span>{post.date}</span>
                            <span>•</span>
                            <span>{post.readTime}</span>
                        </div>
                        <h3 className="font-bold text-lg mb-2 leading-tight group-hover:underline decoration-2 underline-offset-2">
                            {post.title}
                        </h3>
                        <p className="text-sm text-zinc-500 line-clamp-2">
                            {post.excerpt}
                        </p>
                    </Link>
                ))}
            </div>
        </section>
    )
}
