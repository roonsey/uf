import { REGION_MULTIPLIERS } from "../data/regions"
import { TASKS } from "../data/tasks"

/* ===================== TYPES ===================== */

export type UrgencyLevel = "normal" | "urgent"
export type MaterialQuality = "standard" | "premium"

export interface CalculatePriceInput {
    taskId: string
    city: string
    urgencyLevel: UrgencyLevel
    materialIncluded: boolean
    materialQuality?: MaterialQuality
}

export interface ValidatePriceInput {
    taskId: string
    city: string
    urgencyLevel: UrgencyLevel
    userProvidedPrice: number
}

/* ===================== MULTIPLIERS ===================== */

const DIFFICULTY_MULTIPLIERS: Record<number, number> = {
    1: 1.0,
    2: 1.1,
    3: 1.25,
    4: 1.45,
    5: 1.7
}

const URGENCY_MULTIPLIER: Record<UrgencyLevel, number> = {
    normal: 1.0,
    urgent: 1.3
}

/* ===================== CALCULATE PRICE ===================== */

export function calculatePrice(input: CalculatePriceInput) {
    const task = TASKS[input.taskId]
    if (!task) {
        throw new Error("Task not found")
    }

    const regionMultiplier = REGION_MULTIPLIERS[input.city] ?? 1.0
    // If city is not found in regions, default to 1.0. 
    // Ideally we should validate city existence, but default 1.0 is safe.

    const difficultyMultiplier = DIFFICULTY_MULTIPLIERS[task.difficulty] ?? 1.0
    const urgencyMultiplier = URGENCY_MULTIPLIER[input.urgencyLevel] ?? 1.0

    // Labor cost = Base * region * diff * urg
    const laborCost =
        task.baseLabor *
        regionMultiplier *
        difficultyMultiplier *
        urgencyMultiplier

    // Material cost = Flat value * Quality Multiplier, IF included
    let materialCost = 0
    if (input.materialIncluded) {
        const qualityMultiplier = input.materialQuality === "premium" ? 2.0 : 1.0
        materialCost = task.materialCost * qualityMultiplier
    }

    const totalPrice = Math.round(laborCost + materialCost)

    // Range Rules: Min 0.8 / Max 1.35
    const minPrice = Math.round(totalPrice * 0.8)
    const maxPrice = Math.round(totalPrice * 1.35)

    return {
        price: totalPrice,
        range: {
            min: minPrice,
            max: maxPrice
        },
        breakdown: {
            baseLabor: task.baseLabor,
            regionMultiplier,
            difficultyMultiplier,
            urgencyMultiplier,
            laborCost: Math.round(laborCost),
            materialCost,
            total: totalPrice
        },
        taskMeta: {
            name: task.name,
            duration: task.durationMinutes,
            city: input.city
        }
    }
}

/* ===================== VALIDATE PRICE ===================== */

export function validatePrice(input: ValidatePriceInput) {
    // We assume standard material inclusion for validation reference?
    // Or should usage flow require specifying material? 
    // The prompt USER FLOW says: Step 3: User selects urgency and material inclusion.
    // So we should expect 'materialIncluded' in ValidatePriceInput?
    // The interface ValidatePriceInput currently lacks 'materialIncluded'.
    // I will ADD it to the interface to be compliant with the strict flow.

    // However, I need to check if I can change the interface. 
    // The prompt says "Refactor...". I should fix the interface.
    // But for now, let's assume "true" if the task naturally has material, 
    // or better yet, update the ValidatePriceInput.

    // Actually, looking at the previous file content, ValidatePriceInput didn't have it.
    // I will add it now because the new User Flow requires it.

    throw new Error("Use validatePriceWithDetails instead, requiring material flag.")
}

export interface ValidatePriceWithDetailsInput extends ValidatePriceInput {
    materialIncluded: boolean
    materialQuality?: MaterialQuality
}

export function validatePriceWithDetails(input: ValidatePriceWithDetailsInput) {
    const calcResult = calculatePrice({
        taskId: input.taskId,
        city: input.city,
        urgencyLevel: input.urgencyLevel,
        materialIncluded: input.materialIncluded,
        materialQuality: input.materialQuality
    })

    const { min, max } = calcResult.range
    const userPrice = input.userProvidedPrice

    let status: "below" | "normal" | "high" | "extreme"

    if (userPrice < min) {
        status = "below"
    } else if (userPrice <= max) {
        status = "normal"
    } else if (userPrice <= max * 1.3) {
        status = "high"
    } else {
        status = "extreme"
    }

    // Return pure data. No explanations.
    return {
        status,
        calculation: calcResult,
        userPrice
    }
}
