import Link from "next/link"
import { BLOG_POSTS } from "../../../data/blog-posts"
// Actually, since I can't easily install new deps, I will just render text with newlines or basic formatting logic.

export async function generateStaticParams() {
    return BLOG_POSTS.map((post) => ({
        slug: post.slug,
    }))
}

export async function generateMetadata({ params }: { params: { slug: string } }) {
    const { slug } = await params
    const post = BLOG_POSTS.find(p => p.slug === slug)
    if (!post) return {}
    return {
        title: `${post.title} | UstaFiyat Blog`,
        description: post.excerpt,
    }
}

export default async function BlogPostPage({ params }: { params: { slug: string } }) {
    const { slug } = await params
    const post = BLOG_POSTS.find(p => p.slug === slug)

    if (!post) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="text-center">
                    <h1 className="text-4xl font-bold mb-4">404</h1>
                    <p className="text-zinc-500 mb-6">Yazı bulunamadı.</p>
                    <Link href="/" className="text-black underline">Ana Sayfaya Dön</Link>
                </div>
            </div>
        )
    }

    return (
        <article className="min-h-screen bg-white">
            <div className="max-w-2xl mx-auto py-16 px-4">
                <Link href="/" className="inline-flex items-center text-sm text-zinc-500 hover:text-black mb-8 transition-colors">
                    ← Ana Sayfaya Dön
                </Link>

                <div className="text-center mb-10">
                    <div className="text-6xl mb-6">{post.image}</div>
                    <h1 className="text-3xl md:text-4xl font-bold mb-4 tracking-tight leading-tight">{post.title}</h1>
                    <div className="flex items-center justify-center gap-2 text-sm text-zinc-400">
                        <span>{post.date}</span>
                        <span>•</span>
                        <span>{post.readTime}</span>
                    </div>
                </div>

                <div className="prose prose-zinc prose-lg mx-auto">
                    {/* Basic Markdown-ish rendering */}
                    {post.content.split('\n').map((line, i) => {
                        const l = line.trim()
                        if (l.startsWith('## ')) return <h2 key={i} className="text-2xl font-bold mt-8 mb-4">{l.replace('## ', '')}</h2>
                        if (l.startsWith('### ')) return <h3 key={i} className="text-xl font-bold mt-6 mb-3">{l.replace('### ', '')}</h3>
                        if (l.startsWith('* ')) return <li key={i} className="ml-4 mb-2">{l.replace('* ', '')}</li>
                        if (l === '') return <div key={i} className="h-2"></div>
                        return <p key={i} className="mb-4 text-zinc-700 leading-relaxed">{l}</p>
                    })}
                </div>

                <hr className="my-10 border-zinc-100" />

                <div className="bg-zinc-50 p-6 rounded-2xl text-center">
                    <h3 className="font-bold text-lg mb-2">Bu fiyatlar size uygun mu?</h3>
                    <p className="text-zinc-500 mb-4 text-sm">Hemen hesaplama aracımızı kullanarak kendi işiniz için net fiyat aralığını öğrenin.</p>
                    <Link href="/" className="inline-block bg-black text-white px-6 py-3 rounded-xl font-medium hover:bg-zinc-800 transition-colors">
                        Fiyat Hesapla
                    </Link>
                </div>
            </div>
        </article>
    )
}
