export interface TaskConfig {
    id: string;
    name: string;
    baseLabor: number;
    difficulty: number;
    durationMinutes: number;
    materialCost: number;
    slug: string;
}

export interface Task extends TaskConfig {
    categoryId: string;
    popular?: boolean;
}

export const TASKS: Record<string, Task> = {
    // --- SU TESİSATI ---
    "plumb-1": {
        id: "plumb-1",
        categoryId: "plumbing",
        name: "Musluk/Batarya Değişimi",
        slug: "musluk-batarya-degisimi",
        baseLabor: 750, // Updated 2025 avg
        difficulty: 2,
        durationMinutes: 45,
        materialCost: 1200, // Avg faucet cost
        popular: true
    },
    "plumb-2": {
        id: "plumb-2",
        categoryId: "plumbing",
        name: "Lavabo Sifonu Değişimi",
        slug: "lavabo-sifonu-degisimi",
        baseLabor: 600,
        difficulty: 1,
        durationMinutes: 30,
        materialCost: 250
    },
    "plumb-3": {
        id: "plumb-3",
        categoryId: "plumbing",
        name: "Gömme Rezervuar Tamiri",
        slug: "gomme-rezervuar-tamiri",
        baseLabor: 1200,
        difficulty: 4,
        durationMinutes: 90,
        materialCost: 800
    },
    "plumb-4": {
        id: "plumb-4",
        categoryId: "plumbing",
        name: "Tıkalı Gider Açma (Robotlu)",
        slug: "tikali-gider-acma",
        baseLabor: 1500,
        difficulty: 3,
        durationMinutes: 60,
        materialCost: 0,
        popular: true
    },
    "plumb-5": {
        id: "plumb-5",
        categoryId: "plumbing",
        name: "Su Kaçağı Tespiti (Cihazla)",
        slug: "su-kacagi-tespiti",
        baseLabor: 2000,
        difficulty: 4,
        durationMinutes: 90,
        materialCost: 0
    },

    // --- ELEKTRİK ---
    "elec-1": {
        id: "elec-1",
        categoryId: "electric",
        name: "Avize Montajı (Tekli)",
        slug: "avize-montaji",
        baseLabor: 950, // Updated 2025 avg (900-1100 range)
        difficulty: 2,
        durationMinutes: 45,
        materialCost: 100
    },
    "elec-2": {
        id: "elec-2",
        categoryId: "electric",
        name: "Priz / Anahtar Değişimi (Adet)",
        slug: "priz-anahtar-degisimi",
        baseLabor: 350, // Per piece, but user usually has >1. Base visit fee is implied in engine logic somewhat or needs min fee.
        // For single item, usually a minimum service charge applies. 
        // Let's set a higher base to account for "Service Call" nature of single item.
        difficulty: 1,
        durationMinutes: 20,
        materialCost: 150
    },
    "elec-3": {
        id: "elec-3",
        categoryId: "electric",
        name: "Sigorta Panosu Arıza/Değişim",
        slug: "sigorta-panosu-ariza",
        baseLabor: 1500,
        difficulty: 4,
        durationMinutes: 90,
        materialCost: 1000
    },
    "elec-4": {
        id: "elec-4",
        categoryId: "electric",
        name: "Korniş Montajı (Oda Başı)",
        slug: "kornis-montaji",
        baseLabor: 800, // Per room avg seems safer than per meter for this UI
        difficulty: 2,
        durationMinutes: 45,
        materialCost: 300
    },

    // --- ISITMA ---
    "heat-1": {
        id: "heat-1",
        categoryId: "heating",
        name: "Kombi Yıllık Bakımı",
        slug: "kombi-bakimi",
        baseLabor: 1800, // Updated 2025 avg (1500-2000 range)
        difficulty: 2,
        durationMinutes: 45,
        materialCost: 0,
        popular: true
    },
    "heat-2": {
        id: "heat-2",
        categoryId: "heating",
        name: "Petek Temizliği (Daire)",
        slug: "petek-temizligi",
        baseLabor: 1200, // Updated 2025 (800-1500 range)
        difficulty: 3,
        durationMinutes: 120,
        materialCost: 0,
        popular: true
    },

    // --- BOYA ---
    "paint-1": {
        id: "paint-1",
        categoryId: "painting",
        name: "Oda Boyama (10-15m²)",
        slug: "oda-boyama",
        baseLabor: 4000,
        difficulty: 3,
        durationMinutes: 300,
        materialCost: 2000
    },
    "paint-2": {
        id: "paint-2",
        categoryId: "painting",
        name: "2+1 Daire Boyama (Boş)",
        slug: "daire-boyama-2-1",
        baseLabor: 14000,
        difficulty: 4,
        durationMinutes: 1440, // 2-3 days
        materialCost: 6000,
        popular: true
    },
    "paint-3": {
        id: "paint-3",
        categoryId: "painting",
        name: "3+1 Daire Boyama (Boş)",
        slug: "daire-boyama-3-1",
        baseLabor: 18000,
        difficulty: 4,
        durationMinutes: 2000, // 3-4 days
        materialCost: 8000
    },

    // --- KLİMA ---
    "ac-1": {
        id: "ac-1",
        categoryId: "ac",
        name: "Klima Montajı (Split 9-12k)",
        slug: "klima-montaji",
        baseLabor: 2800, // 2025 Avg
        difficulty: 4,
        durationMinutes: 120,
        materialCost: 800, // Pipes etc
        popular: true
    },
    "ac-2": {
        id: "ac-2",
        categoryId: "ac",
        name: "Klima Bakımı (Periyodik)",
        slug: "klima-bakimi",
        baseLabor: 1400, // 2025 Avg
        difficulty: 2,
        durationMinutes: 60,
        materialCost: 0
    },
    "ac-3": {
        id: "ac-3",
        categoryId: "ac",
        name: "Klima Gaz Dolumu",
        slug: "klima-gaz-dolumu",
        baseLabor: 1000,
        difficulty: 2,
        durationMinutes: 45,
        materialCost: 1000 // Gas cost
    },

    // --- ÇİLİNGİR ---
    "lock-1": {
        id: "lock-1",
        categoryId: "locksmith",
        name: "Kapı Açma (Çekili)",
        slug: "kapi-acma-cekili",
        baseLabor: 750, // 2025 Avg (500-850)
        difficulty: 2,
        durationMinutes: 15,
        materialCost: 0,
        popular: true
    },
    "lock-2": {
        id: "lock-2",
        categoryId: "locksmith",
        name: "Kapı Açma (Kilitli)",
        slug: "kapi-acma-kilitli",
        baseLabor: 1200, // 2025 Avg
        difficulty: 4,
        durationMinutes: 45,
        materialCost: 0
    },
    "lock-3": {
        id: "lock-3",
        categoryId: "locksmith",
        name: "Kilit Göbeği Değişimi",
        slug: "kilit-gobegi-degisimi",
        baseLabor: 600,
        difficulty: 2,
        durationMinutes: 20,
        materialCost: 800 // Avg Kale Kilit
    },

    // --- TEMİZLİK ---
    "clean-1": {
        id: "clean-1",
        categoryId: "cleaning",
        name: "Koltuk Yıkama (3'lü Çekyat)",
        slug: "koltuk-yikama",
        baseLabor: 1200, // 2025 Avg
        difficulty: 3,
        durationMinutes: 60,
        materialCost: 0
    },
    "clean-2": {
        id: "clean-2",
        categoryId: "cleaning",
        name: "Ev Temizliği (Tam Gün)",
        slug: "ev-temizligi-tam-gun",
        baseLabor: 3000, // 2025 Avg
        difficulty: 4,
        durationMinutes: 480,
        materialCost: 0,
        popular: true
    },

    // --- TADİLAT ---
    "renov-1": {
        id: "renov-1",
        categoryId: "general",
        name: "Amerikan Kapı Montajı (Adet)",
        slug: "amerikan-kapi-montaji",
        baseLabor: 2000, // 2025 Avg (1800-2300)
        difficulty: 3,
        durationMinutes: 120,
        materialCost: 200 // Foams etc
    },
    "renov-2": {
        id: "renov-2",
        categoryId: "general",
        name: "Laminat Parke İşçiliği (20m² Oda)",
        slug: "laminat-parke-isciligi",
        baseLabor: 3000, // ~150 TL/m2 * 20m2
        difficulty: 3,
        durationMinutes: 180,
        materialCost: 200 // Underlayment etc if not included
    }
};
