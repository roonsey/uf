import { motion } from "framer-motion"

interface AnalysisCardProps {
    data: any;
    explanation: string;
    city: string;
    taskName: string;
}

export function AnalysisCard({ data, explanation, city, taskName }: AnalysisCardProps) {
    const { status, calculation, userPrice } = data.data
    const { min, max } = calculation.range

    const isFair = status === 'normal' || status === 'below'
    const dateStr = new Date().toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' })

    const statusColor = {
        below: "bg-emerald-100 text-emerald-800 border-emerald-200",
        normal: "bg-blue-100 text-blue-800 border-blue-200",
        high: "bg-orange-100 text-orange-800 border-orange-200",
        extreme: "bg-red-100 text-red-800 border-red-200"
    }[status as string] || "bg-gray-100"

    const statusLabel = {
        below: "Fırsat Fiyat",
        normal: "Adil Piyasa Fiyatı",
        high: "Piyasa Üstü",
        extreme: "Yüksek Fiyat"
    }[status as string]

    return (
        <div id="analysis-card" className="bg-white p-0 rounded-3xl overflow-hidden shadow-2xl border border-zinc-200 relative">
            {/* Header / Brand Strip */}
            <div className="bg-zinc-900 text-white p-6 flex justify-between items-center">
                <div>
                    <h3 className="font-bold text-lg tracking-tight">UstaFiyat Analiz Raporu</h3>
                    <p className="text-zinc-400 text-xs uppercase tracking-wider">{dateStr}</p>
                </div>
                <div className="w-10 h-10 bg-white text-black rounded-full flex items-center justify-center font-bold">
                    UF
                </div>
            </div>

            <div className="p-8">
                {/* Main Result */}
                <div className="flex flex-col items-center justify-center text-center mb-8">
                    <span className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest mb-4 border ${statusColor}`}>
                        {statusLabel}
                    </span>

                    <div className="flex items-baseline justify-center gap-2 mb-2">
                        <span className="text-5xl font-bold tracking-tighter text-zinc-900">{userPrice}</span>
                        <span className="text-xl text-zinc-400">TL</span>
                    </div>
                    <p className="text-zinc-500 text-sm">{city} • {taskName}</p>
                </div>

                {/* Range Bar Visualization */}
                <div className="mb-8">
                    <div className="flex justify-between text-xs font-medium text-zinc-400 mb-2">
                        <span>Piyasa Altı</span>
                        <span>Ortalama</span>
                        <span>Piyasa Üstü</span>
                    </div>
                    <div className="h-4 bg-zinc-100 rounded-full relative overflow-hidden">
                        {/* Safe Zone */}
                        <div
                            className="absolute top-0 bottom-0 bg-blue-100/50 border-x border-blue-200"
                            style={{
                                left: '20%',
                                right: '20%' // Visual representation of "Normal" range
                            }}
                        />

                        {/* Market range markers (simplified visual) */}
                        <div className="absolute top-1 bottom-1 left-[20%] w-[1px] bg-blue-300"></div>
                        <div className="absolute top-1 bottom-1 right-[20%] w-[1px] bg-blue-300"></div>

                        {/* User Dot */}
                        <motion.div
                            initial={{ left: '0%' }}
                            animate={{
                                left: status === 'below' ? '10%' :
                                    status === 'normal' ? '50%' :
                                        status === 'high' ? '85%' : '95%'
                            }}
                            className={`absolute top-0 bottom-0 w-1.5 rounded-full shadow-lg ${isFair ? 'bg-emerald-500' : 'bg-red-500'
                                }`}
                        />
                    </div>
                    <div className="mt-2 flex justify-between text-[11px] text-zinc-400 font-mono">
                        <span>{min} TL</span>
                        <span className="font-bold text-zinc-900">Referans Aralık</span>
                        <span>{max} TL</span>
                    </div>
                </div>

                {/* AI Explanation */}
                <div className="bg-zinc-50 p-5 rounded-xl border border-zinc-100 text-sm text-zinc-600 leading-relaxed mb-6">
                    {explanation}
                </div>

                {/* Footer / Trust Badge */}
                <div className="flex items-center gap-3 border-t pt-4">
                    <div className="shrink-0">
                        {/* Shield Icon SVG */}
                        <svg className="w-8 h-8 text-zinc-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                        </svg>
                    </div>
                    <div>
                        <p className="text-[10px] text-zinc-400 uppercase tracking-wide font-bold">Tarafsız Algoritma</p>
                        <p className="text-[10px] text-zinc-400">
                            ustafiyat.com verileri 2024-2025 piyasa ortalamalarına dayanır.
                            Kesin teklif niteliği taşımaz.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    )
}
