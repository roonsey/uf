"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"

interface HistoryItem {
    id: string
    date: number
    taskName: string
    city: string
    price: number
    status: string
}

export function RecentCalculations() {
    const [history, setHistory] = useState<HistoryItem[]>([])
    const [isOpen, setIsOpen] = useState(false)

    useEffect(() => {
        // Load from local storage
        const saved = localStorage.getItem("ustafiyat_history")
        if (saved) {
            try {
                setHistory(JSON.parse(saved).slice(0, 5)) // Last 5
            } catch (e) {
                console.error("Failed to parse history", e)
            }
        }
    }, [isOpen]) // Reload when opened

    if (history.length === 0) return null

    return (
        <div className="fixed bottom-4 right-4 z-40">
            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ opacity: 0, y: 20, scale: 0.9 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 20, scale: 0.9 }}
                        className="absolute bottom-16 right-0 w-80 bg-white rounded-2xl shadow-2xl border border-zinc-200 overflow-hidden mb-2 origin-bottom-right"
                    >
                        <div className="bg-zinc-50 p-3 border-b border-zinc-100 flex justify-between items-center">
                            <h3 className="font-bold text-sm">Son Hesaplamalar</h3>
                            <button onClick={() => setHistory([])} className="text-xs text-red-500 hover:text-red-700">Temizle</button>
                        </div>
                        <div className="max-h-60 overflow-y-auto">
                            {history.map((item) => (
                                <div key={item.id} className="p-3 border-b border-zinc-50 hover:bg-zinc-50 transition-colors">
                                    <div className="flex justify-between mb-1">
                                        <span className="font-medium text-sm text-zinc-900">{item.taskName}</span>
                                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium
                                            ${item.status === 'fair' ? 'bg-green-100 text-green-700' :
                                                item.status === 'high' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'}`}>
                                            {item.status === 'fair' ? 'Adil' : item.status === 'high' ? 'Yüksek' : 'Düşük'}
                                        </span>
                                    </div>
                                    <div className="flex justify-between text-xs text-zinc-500">
                                        <span>{item.city}</span>
                                        <span className="text-zinc-900 font-semibold">{item.price} TL</span>
                                    </div>
                                    <div className="text-[10px] text-zinc-300 mt-1">
                                        {new Date(item.date).toLocaleDateString('tr-TR')}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            <button
                onClick={() => setIsOpen(!isOpen)}
                className="bg-black text-white w-14 h-14 rounded-full shadow-lg flex items-center justify-center hover:scale-110 active:scale-95 transition-all"
            >
                {isOpen ? '✕' : '🕒'}
            </button>
        </div>
    )
}

export function saveToHistory(item: Omit<HistoryItem, "id" | "date">) {
    try {
        const saved = localStorage.getItem("ustafiyat_history")
        let history: HistoryItem[] = saved ? JSON.parse(saved) : []

        const newItem: HistoryItem = {
            ...item,
            id: Math.random().toString(36).substr(2, 9),
            date: Date.now()
        }

        // Add to top, keep limit 10
        history = [newItem, ...history].slice(0, 10)

        localStorage.setItem("ustafiyat_history", JSON.stringify(history))
    } catch (e) {
        console.error("Failed to save history", e)
    }
}
