"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { CATEGORIES } from "../data/categories"
import { TASKS } from "../data/tasks"
import { REGIONS } from "../data/regions"
import { DISTRICTS } from "../data/districts"
import { calculatePrice } from "../lib/pricing-engine"
import { AnalysisCard } from "../components/AnalysisCard"
import { FeedbackForm } from "../components/FeedbackForm"
import { PackageCalculator } from "../components/PackageCalculator"
import { FAQ } from "../components/FAQ"
import { SmartSearch } from "../components/SmartSearch"
import { BlogSection } from "../components/BlogSection"
import { NearbyCraftsmenMap } from "../components/NearbyCraftsmenMap"
import { RecentCalculations, saveToHistory } from "../components/RecentCalculations"

export default function Home() {
  // State
  const [step, setStep] = useState(1) // Can be 1, 2, 2.5, 3, 4
  const [selectedCategory, setSelectedCategory] = useState("")
  const [taskId, setTaskId] = useState("")
  const [city, setCity] = useState("")
  const [district, setDistrict] = useState("")
  const [urgency, setUrgency] = useState<"normal" | "urgent">("normal")
  const [material, setMaterial] = useState(false)
  const [materialQuality, setMaterialQuality] = useState<"standard" | "premium">("standard")
  const [price, setPrice] = useState("")

  const [result, setResult] = useState<any>(null)
  const [loading, setLoading] = useState(false)

  // Derived Data
  const categoryTasks = Object.values(TASKS).filter(t => t.categoryId === selectedCategory)
  // Progress bar logic: Simplified
  const progress = Math.min((step / 4) * 100, 100)

  // Handlers
  const nextStep = () => setStep(s => {
    if (s === 2.5) return 3
    return Math.min(s + 1, 4)
  })

  const prevStep = () => setStep(s => {
    if (s === 3 && district) return 2.5
    if (s === 2.5) return 2
    return Math.max(s - 1, 1)
  })

  const handleCheckPrice = async () => {
    setLoading(true)
    try {
      const res = await fetch("/api/price/validate", {
        method: "POST",
        body: JSON.stringify({
          taskId,
          city,
          urgencyLevel: urgency,
          materialIncluded: material,
          materialQuality,
          userProvidedPrice: price
        })
      })
      const data = await res.json()
      setResult(data)

      // Save to History
      if (data && data.data) {
        saveToHistory({
          taskName: TASKS[taskId]?.name || taskId,
          city: city,
          price: Number(price),
          status: data.data.status
        })
      }

    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  const reset = () => {
    setStep(1)
    setResult(null)
    setPrice("")
    setTaskId("")
    setSelectedCategory("")
    setDistrict("")
  }

  const handleShare = () => {
    if (!result) return
    const text = `UstaFiyat Analizi: ${city}/${district} bölgesinde ${TASKS[taskId]?.name} için ${price} TL fiyat teklifi aldım. UstaFiyat sonucu: ${result.data.status.toUpperCase()}. Referans aralık: ${result.data.calculation.range.min} TL - ${result.data.calculation.range.max} TL.`
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`
    window.open(url, '_blank')
  }

  const handleSearchSelect = (selectedTaskId: string, catId: string) => {
    setSelectedCategory(catId)
    setTaskId(selectedTaskId)
    setStep(2) // Skip directly to City selection
  }

  return (
    <main className="min-h-screen bg-zinc-50 flex flex-col items-center py-12 px-4 font-sans text-zinc-900 pb-24">

      {/* Header */}
      <div className="text-center mb-8 max-w-lg">
        <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-black text-white text-xl font-bold mb-4 shadow-lg">
          UF
        </div>
        <h1 className="text-3xl font-bold tracking-tight mb-2">UstaFiyat</h1>
        <p className="text-zinc-500">
          Hizmet fiyatlarını şeffaf bir şekilde doğrulayın.
        </p>
      </div>

      {/* Main Card */}
      <div className="w-full max-w-xl bg-white rounded-3xl shadow-xl overflow-hidden border border-zinc-100 relative mb-12">

        {/* Progress Bar */}
        <div className="h-1 bg-zinc-100 w-full">
          <div
            className="h-full bg-black transition-all duration-500 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>

        <div className="p-8 min-h-[400px]">
          <AnimatePresence mode="wait">

            {/* STEP 1: CATEGORY & TASK */}
            {step === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <h2 className="text-2xl font-semibold">Ne yaptırmak istiyorsunuz?</h2>

                {/* SMART SEARCH BAR */}
                <SmartSearch onTaskSelect={handleSearchSelect} />

                {!selectedCategory ? (
                  <>
                    <p className="text-sm text-zinc-400 text-center -mt-2 mb-4">veya kategorilerden seçin</p>
                    <div className="grid grid-cols-2 gap-4">
                      {CATEGORIES.map(cat => (
                        <button
                          key={cat.id}
                          onClick={() => setSelectedCategory(cat.id)}
                          className="flex flex-col items-center justify-center p-6 rounded-2xl border border-zinc-200 hover:border-black hover:bg-zinc-50 transition-all group"
                        >
                          <span className="text-4xl mb-3 group-hover:scale-110 transition-transform">{cat.icon}</span>
                          <span className="font-medium">{cat.name}</span>
                        </button>
                      ))}
                    </div>
                  </>
                ) : (
                  <div className="space-y-4">
                    <button
                      onClick={() => setSelectedCategory("")}
                      className="text-sm text-zinc-500 hover:text-black flex items-center mb-2"
                    >
                      ← Kategorilere Dön
                    </button>

                    <div className="space-y-2">
                      {categoryTasks.map(task => (
                        <button
                          key={task.id}
                          onClick={() => {
                            setTaskId(task.id)
                            nextStep()
                          }}
                          className="w-full text-left p-4 rounded-xl border border-zinc-200 hover:border-black hover:bg-zinc-50 transition-all flex items-center justify-between group"
                        >
                          <span className="font-medium">{task.name}</span>
                          <span className="text-zinc-400 group-hover:text-black">→</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {/* STEP 2: CITY */}
            {step === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-semibold">Neredesiniz?</h2>
                  <span className="text-sm text-zinc-400">Adım 2/5</span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {REGIONS.map(r => (
                    <button
                      key={r.id}
                      onClick={() => {
                        setCity(r.name)
                        // Check if districts exist
                        if (DISTRICTS[r.name] && DISTRICTS[r.name].length > 0) {
                          setStep(2.5)
                        } else {
                          setDistrict("") // Clear district if none
                          setStep(3)
                        }
                      }}
                      className={`p-4 rounded-xl border text-left transition-all
                                                ${city === r.name
                          ? "border-black bg-zinc-900 text-white"
                          : "border-zinc-200 hover:border-black"}`}
                    >
                      {r.name}
                    </button>
                  ))}
                </div>
                <div className="pt-4 flex justify-start">
                  <button onClick={prevStep} className="text-zinc-400 hover:text-black">Geri</button>
                </div>
              </motion.div>
            )}

            {/* STEP 2.5: DISTRICT */}
            {step === 2.5 && (
              <motion.div
                key="step2.5"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-semibold">{city} - Hangi İlçe?</h2>
                  <span className="text-sm text-zinc-400">Adım 2.5/5</span>
                </div>

                <div className="grid grid-cols-2 gap-3 max-h-[300px] overflow-y-auto">
                  {DISTRICTS[city]?.map(d => (
                    <button
                      key={d.id}
                      onClick={() => {
                        setDistrict(d.name)
                        setStep(3)
                      }}
                      className={`p-4 rounded-xl border text-left transition-all
                                ${district === d.name
                          ? "border-black bg-zinc-900 text-white"
                          : "border-zinc-200 hover:border-black"}`}
                    >
                      {d.name}
                    </button>
                  ))}
                </div>
                <div className="pt-4 flex justify-start">
                  <button onClick={() => setStep(2)} className="text-zinc-400 hover:text-black">Geri</button>
                </div>
              </motion.div>
            )}

            {/* STEP 3: DETAILS */}
            {step === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-semibold">Detaylar</h2>
                  <span className="text-sm text-zinc-400">Adım 3/5</span>
                </div>

                <div className="space-y-4">
                  <div className="p-4 rounded-2xl bg-zinc-50 border border-zinc-200">
                    <label className="block text-sm font-medium mb-3">İşin Aciliyeti</label>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setUrgency("normal")}
                        className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors
                                                    ${urgency === "normal" ? "bg-white shadow text-black" : "text-zinc-500 hover:bg-zinc-200"}`}
                      >
                        Normal
                      </button>
                      <button
                        onClick={() => setUrgency("urgent")}
                        className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors
                                                    ${urgency === "urgent" ? "bg-red-50 text-red-600 border border-red-100" : "text-zinc-500 hover:bg-zinc-200"}`}
                      >
                        Acil Durum
                      </button>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div
                      onClick={() => setMaterial(!material)}
                      className={`p-4 rounded-2xl border cursor-pointer flex items-center justify-between transition-all
                                                ${material ? "border-blue-500 bg-blue-50" : "border-zinc-200 hover:bg-zinc-50"}`}
                    >
                      <div>
                        <div className="font-medium text-zinc-900">Malzeme Dahil</div>
                        <div className="text-sm text-zinc-500">Fiyata yedek parça/malzeme dahil mi?</div>
                      </div>
                      <div className={`w-6 h-6 rounded-full border flex items-center justify-center
                                                ${material ? "bg-blue-500 border-blue-500" : "border-zinc-300"}`}
                      >
                        {material && <span className="text-white text-xs">✓</span>}
                      </div>
                    </div>

                    {material && (
                      <div className="pl-4 border-l-2 border-blue-100 ml-4 animate-in slide-in-from-left-2 fade-in duration-300">
                        <div className="text-xs font-semibold text-blue-800 uppercase tracking-wide mb-2">Malzeme Kalitesi</div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => setMaterialQuality("standard")}
                            className={`flex-1 py-3 px-3 rounded-xl border text-sm font-medium transition-all ${materialQuality === "standard"
                                ? "bg-white border-blue-500 shadow-sm text-blue-700"
                                : "bg-transparent border-transparent text-zinc-500 hover:bg-zinc-100"
                              }`}
                          >
                            Standart
                          </button>
                          <button
                            onClick={() => setMaterialQuality("premium")}
                            className={`flex-1 py-3 px-3 rounded-xl border text-sm font-medium transition-all ${materialQuality === "premium"
                                ? "bg-gradient-to-r from-amber-50 to-orange-50 border-orange-200 text-orange-800 shadow-sm"
                                : "bg-transparent border-transparent text-zinc-500 hover:bg-zinc-100"
                              }`}
                          >
                            ⭐ Premium / Lüks
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div className="pt-4 flex justify-between items-center">
                  <button onClick={prevStep} className="text-zinc-400 hover:text-black">Geri</button>
                  <button
                    onClick={nextStep}
                    className="bg-black text-white px-6 py-3 rounded-xl font-medium"
                  >
                    Devam Et
                  </button>
                </div>
              </motion.div>
            )}

            {/* STEP 4: PRICE & RESULT */}
            {step === 4 && (
              <motion.div
                key="step4"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                {!result ? (
                  <>
                    <div className="flex items-center justify-between">
                      <h2 className="text-2xl font-semibold">Fiyat Kontrolü</h2>
                      <span className="text-sm text-zinc-400">Son Adım</span>
                    </div>

                    <div className="space-y-4">
                      <label className="block text-sm text-zinc-500">Ustanın verdiği fiyat nedir?</label>
                      <div className="relative">
                        <input
                          type="number"
                          value={price}
                          onChange={(e) => setPrice(e.target.value)}
                          className="w-full text-4xl font-bold p-4 bg-zinc-50 border-b-2 border-zinc-200 focus:border-black outline-none transition-colors placeholder:text-zinc-300"
                          placeholder="0"
                          autoFocus
                        />
                        <span className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-400 font-medium">TL</span>
                      </div>
                    </div>

                    <button
                      onClick={handleCheckPrice}
                      disabled={!price || loading}
                      className="w-full bg-black text-white py-4 rounded-xl font-bold text-lg hover:bg-zinc-800 disabled:opacity-50 disabled:cursor-not-allowed transition-all mt-8"
                    >
                      {loading ? "Analiz Ediliyor..." : "Kontrol Et"}
                    </button>

                    <div className="pt-4 text-center">
                      <button onClick={prevStep} className="text-zinc-400 hover:text-black text-sm">Düzenle</button>
                    </div>
                  </>
                ) : (
                  <div className="pt-2">
                    <AnalysisCard
                      data={result}
                      explanation={result.explanation}
                      city={city}
                      taskName={TASKS[taskId]?.name}
                    />

                    <div className="mt-6 grid grid-cols-2 gap-3">
                      <button
                        onClick={handleShare}
                        className="flex items-center justify-center gap-2 py-3 px-4 bg-green-500 text-white rounded-xl font-semibold hover:bg-green-600 transition-colors"
                      >
                        <span>WhatsApp Paylaş</span>
                      </button>
                      <button
                        onClick={reset}
                        className="py-3 px-4 border border-zinc-200 text-zinc-600 rounded-xl font-medium hover:bg-zinc-50 transition-colors"
                      >
                        Yeni Sorgu
                      </button>
                    </div>

                    <FeedbackForm
                      taskId={taskId}
                      city={city}
                      initialPrice={Number(price)}
                    />

                    <NearbyCraftsmenMap city={city} district={district} taskId={taskId} />
                  </div>
                )}
              </motion.div>
            )}

          </AnimatePresence>
        </div>
      </div>

      <PackageCalculator />
      <FAQ />
      <BlogSection />
      <RecentCalculations />

    </main>
  )
}
