"use client"

import { useState, useRef, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { TASKS, Task } from "../data/tasks"
import { useRouter } from "next/navigation"

interface SmartSearchProps {
    onTaskSelect: (taskId: string, categoryId: string) => void
}

export function SmartSearch({ onTaskSelect }: SmartSearchProps) {
    const [query, setQuery] = useState("")
    const [results, setResults] = useState<Task[]>([])
    const [isOpen, setIsOpen] = useState(false)
    const inputRef = useRef<HTMLInputElement>(null)
    const containerRef = useRef<HTMLDivElement>(null)

    // Close on click outside
    useEffect(() => {
        function handleClickOutside(event: MouseEvent) {
            if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
                setIsOpen(false)
            }
        }
        document.addEventListener("mousedown", handleClickOutside)
        return () => document.removeEventListener("mousedown", handleClickOutside)
    }, [])

    const handleSearch = (text: string) => {
        setQuery(text)
        if (text.length < 2) {
            setResults([])
            setIsOpen(false)
            return
        }

        // Simple fuzzy-like search (includes check)
        // Normalize Turkish characters for better search (e.g. "musluk" finds "Musluk")
        const lowerQuery = text.toLocaleLowerCase("tr-TR")

        const filtered = Object.values(TASKS).filter(task => {
            const taskName = task.name.toLocaleLowerCase("tr-TR")
            return taskName.includes(lowerQuery)
        })

        setResults(filtered)
        setIsOpen(true)
    }

    const handleSelect = (task: Task) => {
        setQuery(task.name)
        setIsOpen(false)
        onTaskSelect(task.id, task.categoryId)
    }

    return (
        <div ref={containerRef} className="relative w-full max-w-lg mx-auto mb-8 z-50">
            <div className="relative group">
                <input
                    ref={inputRef}
                    type="text"
                    value={query}
                    onChange={(e) => handleSearch(e.target.value)}
                    onFocus={() => query.length >= 2 && setIsOpen(true)}
                    placeholder="Örn: Musluk, Boya, Kombi..."
                    className="w-full p-4 pl-12 rounded-2xl border-2 border-zinc-200 outline-none focus:border-black transition-all shadow-sm text-lg placeholder:text-zinc-400"
                />
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400 text-xl group-focus-within:text-black transition-colors">
                    🔍
                </span>

                {query.length > 0 && (
                    <button
                        onClick={() => { setQuery(""); setIsOpen(false); inputRef.current?.focus() }}
                        className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-300 hover:text-black hover:bg-zinc-100 rounded-full w-6 h-6 flex items-center justify-center transition-all"
                    >
                        ✕
                    </button>
                )}
            </div>

            <AnimatePresence>
                {isOpen && results.length > 0 && (
                    <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.98 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.98 }}
                        transition={{ duration: 0.2 }}
                        className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-2xl border border-zinc-100 overflow-hidden max-h-[300px] overflow-y-auto"
                    >
                        <div className="p-2">
                            {results.map((task) => (
                                <button
                                    key={task.id}
                                    onClick={() => handleSelect(task)}
                                    className="w-full text-left p-3 hover:bg-zinc-50 rounded-xl transition-colors flex items-center justify-between group"
                                >
                                    <div className="flex items-center gap-3">
                                        <div className="w-8 h-8 rounded-lg bg-zinc-100 flex items-center justify-center text-sm group-hover:bg-black group-hover:text-white transition-colors">
                                            {/* We can map icons here later, or use simple emojis */}
                                            🔧
                                        </div>
                                        <div>
                                            <div className="font-medium text-zinc-900">{task.name}</div>
                                            <div className="text-xs text-zinc-400">{task.durationMinutes} dk • Zorluk {task.difficulty}/5</div>
                                        </div>
                                    </div>
                                    <span className="text-zinc-300 group-hover:text-black group-hover:translate-x-1 transition-all">→</span>
                                </button>
                            ))}
                        </div>
                    </motion.div>
                )}

                {isOpen && results.length === 0 && query.length >= 2 && (
                    <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-xl p-4 text-center border border-zinc-100"
                    >
                        <p className="text-zinc-500 text-sm">Sonuç bulunamadı. Lütfen kategorilerden seçin.</p>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    )
}
