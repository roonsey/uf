import { TASKS } from '../data/tasks'
import { REGIONS } from '../data/regions'

export default async function sitemap() {
    const baseUrl = 'https://ustafiyat.com' // Domain you will use

    // Base Routes
    const routes = [
        {
            url: baseUrl,
            lastModified: new Date(),
        },
    ]

    // Dynamic Routes
    // Loop through all Region + Task Combinations
    const dynamicRoutes = []

    for (const city of REGIONS) {
        if (city.id === 'other') continue
        for (const taskKey in TASKS) {
            const task = TASKS[taskKey]
            dynamicRoutes.push({
                url: `${baseUrl}/fiyat/${city.slug}/${task.slug}`,
                lastModified: new Date(),
            })
        }
    }

    return [...routes, ...dynamicRoutes]
}
